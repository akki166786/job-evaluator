"use strict";
(() => {
  // src/lib/types.ts
  var DEFAULT_SETTINGS = {
    profileIntent: "",
    skillsTechStack: "",
    negativeFilters: "",
    apiProvider: "ollama",
    apiKeys: {},
    ollamaModel: "llama3.1:8b"
  };

  // src/lib/db.ts
  var DB_NAME = "linkedin-job-eval-db";
  var DB_VERSION = 2;
  var RESUMES_STORE = "resumes";
  var SETTINGS_STORE = "settings";
  var JOB_EVALS_STORE = "job_evaluations";
  var SETTINGS_KEYS = [
    "profileIntent",
    "skillsTechStack",
    "negativeFilters",
    "apiProvider",
    "apiKeys",
    "ollamaModel"
  ];
  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(RESUMES_STORE)) {
          const r = db.createObjectStore(RESUMES_STORE, { keyPath: "id" });
          r.createIndex("createdAt", "createdAt", { unique: false });
        }
        if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
          db.createObjectStore(SETTINGS_STORE, { keyPath: "key" });
        }
        if (!db.objectStoreNames.contains(JOB_EVALS_STORE)) {
          const evals = db.createObjectStore(JOB_EVALS_STORE, { keyPath: "jobId" });
          evals.createIndex("evaluatedAt", "evaluatedAt", { unique: false });
        }
      };
    });
  }
  async function getAllResumes() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(RESUMES_STORE, "readonly");
      const req = t.objectStore(RESUMES_STORE).getAll();
      req.onsuccess = () => {
        db.close();
        resolve(req.result.sort((a, b) => a.createdAt - b.createdAt));
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  }
  async function getSetting(key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(SETTINGS_STORE, "readonly");
      const req = t.objectStore(SETTINGS_STORE).get(key);
      req.onsuccess = () => {
        db.close();
        const row = req.result;
        const val = row?.value;
        if (val !== void 0) resolve(val);
        else resolve(DEFAULT_SETTINGS[key]);
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  }
  async function getLegacyApiKey() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(SETTINGS_STORE, "readonly");
      const req = t.objectStore(SETTINGS_STORE).get("apiKey");
      req.onsuccess = () => {
        db.close();
        const row = req.result;
        resolve(row?.value);
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  }
  async function setSetting(key, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(SETTINGS_STORE, "readwrite");
      const req = t.objectStore(SETTINGS_STORE).put({ key, value });
      req.onsuccess = () => {
        db.close();
        resolve();
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  }
  async function getSettings() {
    const [profileIntent, skillsTechStack, negativeFilters, apiProvider, apiKeys, ollamaModel, legacyApiKey] = await Promise.all([
      getSetting("profileIntent"),
      getSetting("skillsTechStack"),
      getSetting("negativeFilters"),
      getSetting("apiProvider"),
      getSetting("apiKeys"),
      getSetting("ollamaModel"),
      getLegacyApiKey()
    ]);
    const normalizedApiKeys = apiKeys && Object.keys(apiKeys).length > 0 ? apiKeys : {};
    if (legacyApiKey && !normalizedApiKeys[apiProvider]) {
      normalizedApiKeys[apiProvider] = legacyApiKey;
      await saveSettings({ apiKeys: normalizedApiKeys });
    }
    return { profileIntent, skillsTechStack, negativeFilters, apiProvider, apiKeys: normalizedApiKeys, ollamaModel };
  }
  async function saveSettings(settings) {
    const keys = SETTINGS_KEYS.filter((k) => settings[k] !== void 0);
    await Promise.all(keys.map((k) => setSetting(k, settings[k])));
  }

  // src/lib/prompts.ts
  var SYSTEM_PROMPT = `You are a strict career advisor. Your goal is to save the user's time by reducing wasted applications.
You must respond with ONLY a single valid JSON object. No markdown, no code fences, no text before or after the JSON. Be conservative; scores above 75 should be rare.
Rules for JSON: use only double quotes for strings; use \\n for newlines inside strings (never literal line breaks); no trailing commas after the last item in objects or arrays. Keep explanation and bullet strings short (one short sentence each). Tone: factual, direct, no hype.`;
  function escapeForPrompt(s) {
    return s.replace(/\r\n/g, "\n").trim();
  }
  function buildUserPrompt(job, profileIntent, skillsTechStack, negativeFilters, resumes) {
    const jobBlock = `
## JOB
Title: ${escapeForPrompt(job.title)}
Location: ${escapeForPrompt(job.location)}

Description:
${escapeForPrompt(job.description)}
`.trim();
    const profileBlock = `
## USER PROFILE INTENT (what they want)
${profileIntent ? escapeForPrompt(profileIntent) : "(None provided)"}
`.trim();
    const skillsBlock = `
## USER SKILLS / TECH STACK
${skillsTechStack ? escapeForPrompt(skillsTechStack) : "(None provided)"}
`.trim();
    const negativeBlock = `
## USER NEGATIVE FILTERS (hard deal-breakers; if job violates these, verdict must be not_worth or maybe and score low)
${negativeFilters ? escapeForPrompt(negativeFilters) : "(None provided)"}
`.trim();
    const resumesBlock = resumes.length > 0 ? `
## USER RESUMES (label + text; pick bestResumeLabel from one of these labels)
${resumes.map(
      (r) => `--- Resume: ${r.label} ---
${escapeForPrompt(r.text)}
`
    ).join("\n")}
`.trim() : `
## USER RESUMES
(No resumes provided. Match only against profile intent and skills/tech stack above.)
`.trim();
    const hasResumes = resumes.length > 0;
    const instructions = hasResumes ? `
## INSTRUCTIONS

1. **Phase 1 \u2014 Hard rejection**: Check for clear deal-breakers against the user's negative filters, profile intent, and skills/tech stack (e.g. language like "Fluent Dutch required", on-site-only far from user, tech stack opposite to skills like Java when they list JavaScript, seniority mismatch). If any clear violation: set verdict to "not_worth" or "maybe", set hardRejectionReason, and keep score below 40.

2. **Phase 2 \u2014 Semantic matching**: If not hard-rejected, compare the job to each resume, profile intent, and skills/tech stack. Compute fit (skill overlap, seniority, domain). Choose bestResumeLabel (one of the resume labels that fits best). Score 0\u2013100: ~70% resume\u2013job relevance, ~30% profile+skills alignment. Remain conservative; 75+ only for strong fit.

Respond with ONLY this JSON object (no other text). Example format:
{"score":50,"verdict":"maybe","hardRejectionReason":null,"matchBullets":["skill match"],"riskBullets":["missing X"],"bestResumeLabel":"Frontend","explanation":"One short sentence."}
Required keys: score (0-100 number), verdict ("worth" or "maybe" or "not_worth"), hardRejectionReason (string or null), matchBullets (array of short strings), riskBullets (array of short strings), bestResumeLabel (one of the resume labels), explanation (one short sentence). No trailing commas. No newlines inside strings.
`.trim() : `
## INSTRUCTIONS

1. **Phase 1 \u2014 Hard rejection**: Check for clear deal-breakers against the user's negative filters, profile intent, and skills/tech stack (e.g. language requirements, on-site-only, tech stack opposite to their skills, seniority mismatch). If any clear violation: set verdict to "not_worth" or "maybe", set hardRejectionReason, and keep score below 40.

2. **Phase 2 \u2014 Semantic matching**: No resumes are provided. Match the job only against the user's profile intent and skills/tech stack. Compute fit (skill overlap with job requirements, seniority, domain). Set bestResumeLabel to null. Score 0\u2013100 based on how well the job aligns with intent and skills. Remain conservative; 75+ only for strong fit.

Respond with ONLY this JSON object (no other text). Example format:
{"score":50,"verdict":"maybe","hardRejectionReason":null,"matchBullets":["skill match"],"riskBullets":["missing X"],"bestResumeLabel":null,"explanation":"One short sentence."}
Required keys: score (0-100 number), verdict ("worth" or "maybe" or "not_worth"), hardRejectionReason (string or null), matchBullets (array of short strings), riskBullets (array of short strings), bestResumeLabel (must be null when no resumes), explanation (one short sentence). No trailing commas. No newlines inside strings.
`.trim();
    return [jobBlock, profileBlock, skillsBlock, negativeBlock, resumesBlock, instructions].join("\n\n");
  }

  // src/lib/llm.ts
  var OLLAMA_ENDPOINT = "http://localhost:11434/v1/chat/completions";
  var REQUEST_TIMEOUT_MS = 6e4;
  var OLLAMA_TIMEOUT_MS = 18e4;
  var PROVIDER_MODELS = {
    ollama: "llama3.1:8b",
    openai: "gpt-4o-mini",
    anthropic: "claude-3-haiku-20240307",
    openrouter: "openai/gpt-4o-mini",
    google: "gemini-3-flash-preview",
    groq: "llama-3.1-8b-instant"
  };
  var PROVIDER_ENDPOINTS = {
    ollama: OLLAMA_ENDPOINT,
    openai: "https://api.openai.com/v1/chat/completions",
    anthropic: "https://api.anthropic.com/v1/messages",
    openrouter: "https://openrouter.ai/api/v1/chat/completions",
    google: "https://generativelanguage.googleapis.com/v1beta/models",
    groq: "https://api.groq.com/openai/v1/chat/completions"
  };
  function getAuthHeader(provider, apiKey) {
    if (provider === "ollama") return {};
    if (provider === "anthropic") {
      return {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      };
    }
    if (provider === "google") {
      return { "x-goog-api-key": apiKey };
    }
    return { Authorization: `Bearer ${apiKey}` };
  }
  var KNOWN_RESULT_KEYS = /* @__PURE__ */ new Set([
    "score",
    "verdict",
    "hardRejectionReason",
    "matchBullets",
    "riskBullets",
    "bestResumeLabel",
    "explanation",
    "extraInfo"
  ]);
  function collectExtraInfo(raw) {
    const extra = {};
    const existing = raw.extraInfo;
    if (existing && typeof existing === "object" && !Array.isArray(existing)) {
      Object.assign(extra, existing);
    }
    for (const [key, value] of Object.entries(raw)) {
      if (!KNOWN_RESULT_KEYS.has(key)) {
        extra[key] = value;
      }
    }
    return Object.keys(extra).length > 0 ? extra : null;
  }
  function parseJsonFromResponse(text) {
    let cleaned = text.trim();
    const codeFence = /^```(?:json)?\s*\n?([\s\S]*?)\n?```\s*$/;
    const m = cleaned.match(codeFence);
    if (m) cleaned = m[1].trim();
    const firstBrace = cleaned.indexOf("{");
    if (firstBrace !== -1) {
      let depth = 0;
      let end = -1;
      for (let i = firstBrace; i < cleaned.length; i++) {
        if (cleaned[i] === "{") depth++;
        else if (cleaned[i] === "}") {
          depth--;
          if (depth === 0) {
            end = i;
            break;
          }
        }
      }
      if (end !== -1) cleaned = cleaned.slice(firstBrace, end + 1);
    }
    cleaned = cleaned.replace(/,(\s*[}\]])/g, "$1");
    const repairOrder = [(s) => s, fixNewlinesInsideJsonStrings, coerceSmartQuotes, coerceSingleQuotes];
    for (const repair of repairOrder) {
      try {
        const parsed = JSON.parse(repair(cleaned));
        if (parsed != null && typeof parsed === "object" && "verdict" in parsed) {
          const extraInfo = collectExtraInfo(parsed);
          if (extraInfo) parsed.extraInfo = extraInfo;
          return parsed;
        }
      } catch {
        continue;
      }
    }
    const fallback = extractResultFromBrokenJson(cleaned);
    if (fallback) return fallback;
    throw new Error(
      'The model returned invalid JSON. Try "Evaluate this job" again; if it keeps failing, the model may be overloaded.'
    );
  }
  function fixNewlinesInsideJsonStrings(json) {
    let out = "";
    let i = 0;
    let inString = false;
    let escape = false;
    while (i < json.length) {
      const c = json[i];
      if (escape) {
        out += c;
        escape = false;
        i++;
        continue;
      }
      if (c === "\\") {
        out += c;
        escape = true;
        i++;
        continue;
      }
      if (inString) {
        if (c === '"') {
          inString = false;
          out += c;
        } else if (c === "\n" || c === "\r") {
          out += "\\n";
          if (c === "\r" && json[i + 1] === "\n") i++;
        } else {
          out += c;
        }
        i++;
        continue;
      }
      if (c === '"') {
        inString = true;
        out += c;
      } else {
        out += c;
      }
      i++;
    }
    return out;
  }
  function coerceSmartQuotes(json) {
    return json.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
  }
  function coerceSingleQuotes(json) {
    return json.replace(/'([^'\\]*(?:\\.[^'\\]*)*)'/g, (_, inner) => `"${inner.replace(/"/g, '\\"')}"`);
  }
  function extractResultFromBrokenJson(text) {
    const scoreMatch = text.match(/"score"\s*:\s*(\d+)/);
    const verdictMatch = text.match(/"verdict"\s*:\s*"(worth|maybe|not_worth)"/);
    const score = scoreMatch ? Math.max(0, Math.min(100, parseInt(scoreMatch[1], 10))) : 50;
    const verdict = verdictMatch?.[1] ?? "maybe";
    const explanationMatch = text.match(/"explanation"\s*:\s*"((?:[^"\\]|\\.)*)"/);
    const explanation = explanationMatch ? explanationMatch[1].replace(/\\n/g, "\n").replace(/\\"/g, '"') : "";
    const matchBullets = [];
    const riskBullets = [];
    const bulletRegex = /"(?:matchBullets|riskBullets)"\s*:\s*\[\s*((?:"(?:[^"\\]|\\.)*"\s*,?\s*)*)\]/g;
    let bulletMatch;
    while ((bulletMatch = bulletRegex.exec(text)) !== null) {
      const key = bulletMatch[0].includes("matchBullets") ? "match" : "risk";
      const inner = bulletMatch[1];
      const items = inner.match(/"((?:[^"\\]|\\.)*)"/g);
      if (items) {
        for (const item of items) {
          const unescaped = item.slice(1, -1).replace(/\\n/g, "\n").replace(/\\"/g, '"');
          if (key === "match") matchBullets.push(unescaped);
          else riskBullets.push(unescaped);
        }
      }
    }
    const bestMatch = text.match(/"bestResumeLabel"\s*:\s*(?:"([^"]*)"|null)/);
    const bestResumeLabel = bestMatch ? bestMatch[1] ?? null : null;
    const hardMatch = text.match(/"hardRejectionReason"\s*:\s*(?:"((?:[^"\\]|\\.)*)"|null)/);
    const hardRejectionReason = hardMatch ? hardMatch[1] ?? null : null;
    const MAX_RAW_TEXT_LEN = 500;
    const extraInfo = text ? { rawText: text.length > MAX_RAW_TEXT_LEN ? text.slice(0, MAX_RAW_TEXT_LEN) + "\u2026" : text } : null;
    return {
      score,
      verdict,
      hardRejectionReason,
      matchBullets,
      riskBullets,
      bestResumeLabel,
      explanation,
      extraInfo
    };
  }
  function normalizeResult(raw) {
    const verdict = raw.verdict === "worth" || raw.verdict === "maybe" || raw.verdict === "not_worth" ? raw.verdict : "maybe";
    return {
      score: typeof raw.score === "number" ? Math.max(0, Math.min(100, raw.score)) : 50,
      verdict,
      hardRejectionReason: raw.hardRejectionReason ?? null,
      matchBullets: Array.isArray(raw.matchBullets) ? raw.matchBullets : [],
      riskBullets: Array.isArray(raw.riskBullets) ? raw.riskBullets : [],
      bestResumeLabel: raw.bestResumeLabel ?? null,
      explanation: typeof raw.explanation === "string" ? raw.explanation : "",
      extraInfo: raw.extraInfo ?? null
    };
  }
  async function evaluateJob(job, resumes, profileIntent, skillsTechStack, negativeFilters, provider, apiKey, ollamaModel) {
    if (provider !== "ollama" && !apiKey) {
      throw new Error("API key required for this provider.");
    }
    const model = provider === "ollama" && ollamaModel ? ollamaModel : PROVIDER_MODELS[provider];
    const endpoint = PROVIDER_ENDPOINTS[provider];
    const userPrompt = buildUserPrompt(job, profileIntent, skillsTechStack, negativeFilters, resumes);
    if (provider === "anthropic") {
      const body2 = {
        model,
        max_tokens: 1024,
        messages: [
          { role: "user", content: `${SYSTEM_PROMPT}

${userPrompt}` }
        ]
      };
      const controller2 = new AbortController();
      const timeout2 = setTimeout(() => controller2.abort(), REQUEST_TIMEOUT_MS);
      let res2;
      try {
        res2 = await fetch(endpoint, {
          method: "POST",
          headers: getAuthHeader(provider, apiKey),
          body: JSON.stringify(body2),
          signal: controller2.signal
        });
      } catch (e) {
        clearTimeout(timeout2);
        if (e.name === "AbortError") {
          throw new Error(`Request timed out after ${REQUEST_TIMEOUT_MS / 1e3}s. Try again.`);
        }
        throw e;
      }
      clearTimeout(timeout2);
      if (!res2.ok) {
        const t = await res2.text();
        throw new Error(res2.status === 401 ? "Invalid API key." : res2.status === 429 ? "Rate limited." : t || res2.statusText);
      }
      const data2 = await res2.json();
      const text2 = data2.content?.[0]?.text ?? data2.content ?? "";
      const raw2 = parseJsonFromResponse(text2);
      return normalizeResult(raw2);
    }
    if (provider === "google") {
      const googleEndpoint = `${PROVIDER_ENDPOINTS[provider]}/${model}:generateContent`;
      const body2 = {
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        generationConfig: { maxOutputTokens: 1024 }
      };
      const controller2 = new AbortController();
      const timeout2 = setTimeout(() => controller2.abort(), REQUEST_TIMEOUT_MS);
      let res2;
      try {
        res2 = await fetch(googleEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...getAuthHeader(provider, apiKey)
          },
          body: JSON.stringify(body2),
          signal: controller2.signal
        });
      } catch (e) {
        clearTimeout(timeout2);
        if (e.name === "AbortError") {
          throw new Error(`Request timed out after ${REQUEST_TIMEOUT_MS / 1e3}s. Try again.`);
        }
        throw e;
      }
      clearTimeout(timeout2);
      if (!res2.ok) {
        const t = await res2.text();
        throw new Error(res2.status === 401 ? "Invalid API key." : res2.status === 429 ? "Rate limited." : t || res2.statusText);
      }
      const data2 = await res2.json();
      const text2 = data2.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      const raw2 = parseJsonFromResponse(text2);
      return normalizeResult(raw2);
    }
    const body = {
      model,
      max_tokens: 1024,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt }
      ]
    };
    const timeoutMs = provider === "ollama" ? OLLAMA_TIMEOUT_MS : REQUEST_TIMEOUT_MS;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    let res;
    try {
      res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeader(provider, apiKey)
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });
    } catch (e) {
      clearTimeout(timeout);
      if (e.name === "AbortError") {
        throw new Error(
          provider === "ollama" ? `Request timed out after ${timeoutMs / 1e3}s. Ollama may be slow on CPU\u2014try again or keep the panel open longer.` : `Request to ${provider} timed out after ${timeoutMs / 1e3}s. The API may be overloaded\u2014try again.`
        );
      }
      throw e;
    }
    clearTimeout(timeout);
    if (!res.ok) {
      const t = await res.text();
      if (provider === "ollama") {
        if (res.status === 0 || res.type === "opaque") {
          throw new Error("Could not reach Ollama. Is it running? (e.g. ollama serve or Docker.)");
        }
        if (res.status === 403) {
          throw new Error(
            "Ollama returned Forbidden (403). Start Ollama with OLLAMA_ORIGINS=* to allow this extension. Docker: docker run -e OLLAMA_ORIGINS=* -p 11434:11434 ollama/ollama"
          );
        }
      }
      throw new Error(res.status === 401 ? "Invalid API key." : res.status === 429 ? "Rate limited." : t || res.statusText);
    }
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content ?? "";
    const raw = parseJsonFromResponse(text);
    return normalizeResult(raw);
  }

  // src/background/service-worker.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab?.windowId != null) {
      chrome.sidePanel.open({ windowId: tab.windowId });
    }
  });
  chrome.runtime.onMessage.addListener(
    (msg, _sender, sendResponse) => {
      if (msg.type !== "EVALUATE_JOB" || !msg.job) {
        sendResponse({ error: "Missing job data." });
        return true;
      }
      (async () => {
        try {
          const settings = await getSettings();
          let resumes = await getAllResumes();
          if (settings.apiProvider === "ollama") {
            resumes = [];
          } else if (msg.resumeIds && msg.resumeIds.length > 0) {
            const idSet = new Set(msg.resumeIds);
            resumes = resumes.filter((r) => idSet.has(r.id));
          } else {
            resumes = [];
          }
          const result = await evaluateJob(
            msg.job,
            resumes,
            settings.profileIntent,
            settings.skillsTechStack,
            settings.negativeFilters,
            settings.apiProvider,
            settings.apiKeys?.[settings.apiProvider] ?? "",
            settings.ollamaModel
          );
          sendResponse(result);
        } catch (e) {
          const err = e;
          sendResponse({
            error: err.message || "Evaluation failed.",
            raw: err.message
          });
        }
      })();
      return true;
    }
  );
})();
//# sourceMappingURL=service-worker.js.map
