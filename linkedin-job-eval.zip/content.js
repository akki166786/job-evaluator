"use strict";
(() => {
  // src/content/content.ts
  function getText(el) {
    if (!el) return "";
    return (el.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function queryOne(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && getText(el)) return el;
    }
    return null;
  }
  function getDescriptionText(container) {
    if (!container) return "";
    return getText(container);
  }
  function getJobIdFromUrl() {
    const url = new URL(window.location.href);
    const viewMatch = url.pathname.match(/\/jobs\/view\/(\d+)/);
    if (viewMatch) return viewMatch[1];
    const currentJobId = url.searchParams.get("currentJobId");
    if (currentJobId && /^\d+$/.test(currentJobId)) return currentJobId;
    return null;
  }
  function getJobIdFromDom() {
    const el = document.querySelector("[data-job-id], [data-entity-urn]");
    const jobId = el?.getAttribute("data-job-id");
    if (jobId) return jobId;
    const urn = el?.getAttribute("data-entity-urn");
    if (!urn) return null;
    const urnMatch = urn.match(/:jobPosting:(\d+)/);
    return urnMatch ? urnMatch[1] : null;
  }
  function getMetaContent(name) {
    const el = document.querySelector(`meta[name="${name}"]`) ?? document.querySelector(`meta[property="${name}"]`);
    return el?.getAttribute("content")?.trim() ?? "";
  }
  function parseJsonLdJob() {
    const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
    for (const script of scripts) {
      try {
        const json = JSON.parse(script.textContent ?? "");
        const nodes = Array.isArray(json) ? json : [json];
        for (const node of nodes) {
          if (!node || typeof node !== "object") continue;
          const type = node["@type"];
          if (type === "JobPosting" || Array.isArray(type) && type.includes("JobPosting")) {
            const posting = node;
            const locationParts = [
              posting.jobLocation?.address?.addressLocality,
              posting.jobLocation?.address?.addressRegion,
              posting.jobLocation?.address?.addressCountry
            ].filter(Boolean);
            return {
              title: posting.title?.trim() ?? "",
              description: posting.description?.replace(/\s+/g, " ").trim() ?? "",
              location: locationParts.join(", "),
              id: posting.identifier?.value ?? ""
            };
          }
        }
      } catch {
        continue;
      }
    }
    return null;
  }
  function extractJobData() {
    const jsonLd = parseJsonLdJob();
    const jobId = getJobIdFromDom() ?? getJobIdFromUrl() ?? jsonLd?.id ?? "";
    const titleSelectors = [
      ".job-details-jobs-unified-top-card__job-title",
      // /jobs/view (2024+ layout)
      "h1.t-24",
      // older /jobs/view layout
      "[data-job-id] h1",
      // generic fallback
      ".jobs-unified-top-card__job-title",
      // legacy /jobs/view
      "h1"
      // last resort
    ];
    const titleEl = queryOne(titleSelectors);
    const title = getText(titleEl ?? document.querySelector("h1")) || jsonLd?.title || getMetaContent("og:title");
    const descSelectors = [
      ".jobs-description__content",
      // /jobs/view primary
      ".jobs-description-content__text",
      // /jobs/view variant
      "[data-job-id] .jobs-box__html-content",
      // detail pane in search/collections
      ".show-more-less-html",
      // expandable description wrapper
      ".jobs-box .jobs-box__html-content"
      // legacy fallback
    ];
    const descEl = queryOne(descSelectors) ?? document.querySelector(".jobs-description__content");
    const description = getDescriptionText(descEl) || jsonLd?.description || getMetaContent("description");
    const locationSelectors = [
      ".job-details-jobs-unified-top-card__primary-description-container",
      // /jobs/view (2024+)
      ".jobs-unified-top-card__primary-description",
      // legacy /jobs/view
      ".job-details-how-you-match__secondary-description",
      // match section
      '[data-job-id] span[class*="primary-description"]'
      // generic fallback
    ];
    const locationEl = queryOne(locationSelectors);
    let location = getText(locationEl) || jsonLd?.location || getMetaContent("og:location");
    if (!location) {
      const locSpan = document.querySelector(".jobs-unified-top-card__bullet");
      if (locSpan) location = getText(locSpan.parentElement);
    }
    if (!title && !description) return null;
    return {
      id: jobId || `${title}-${location}`.trim() || "unknown",
      title: title || "Unknown title",
      description: description || "",
      location: location || ""
    };
  }
  chrome.runtime.onMessage.addListener(
    (msg, _sender, sendResponse) => {
      if (msg.type === "GET_JOB_DATA") {
        try {
          const job = extractJobData();
          if (job) sendResponse({ ok: true, job });
          else sendResponse({ ok: false, error: "Could not read job details from this page." });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
      }
      return true;
    }
  );
})();
//# sourceMappingURL=content.js.map
